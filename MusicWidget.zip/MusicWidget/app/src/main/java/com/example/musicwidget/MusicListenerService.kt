package com.example.musicwidget

import android.content.ComponentName
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService

// 通知アクセスを許可すると、他アプリの再生情報（MediaSession）を読める
class MusicListenerService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private var msm: MediaSessionManager? = null
    private var current: MediaController? = null

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: android.media.MediaMetadata?) = refresh()
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { attach(it) }

    // 再生中は2秒ごとに進行バーを更新
    private val ticker = object : Runnable {
        override fun run() {
            if (current?.playbackState?.state == PlaybackState.STATE_PLAYING) {
                MusicWidget.updateAll(applicationContext)
                handler.postDelayed(this, 2000)
            }
        }
    }

    override fun onListenerConnected() {
        val cn = ComponentName(this, MusicListenerService::class.java)
        msm = getSystemService(MediaSessionManager::class.java)
        msm?.addOnActiveSessionsChangedListener(sessionsListener, cn)
        attach(msm?.getActiveSessions(cn))
    }

    override fun onListenerDisconnected() {
        msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        current?.unregisterCallback(callback)
        current = null
        handler.removeCallbacks(ticker)
    }

    private fun attach(list: List<MediaController>?) {
        current?.unregisterCallback(callback)
        current = list?.firstOrNull { it.packageName == MusicWidget.AMAZON_MUSIC }
            ?: list?.firstOrNull()
        current?.registerCallback(callback)
        refresh()
    }

    private fun refresh() {
        MusicWidget.updateAll(applicationContext)
        handler.removeCallbacks(ticker)
        if (current?.playbackState?.state == PlaybackState.STATE_PLAYING) {
            handler.postDelayed(ticker, 2000)
        }
    }
}
