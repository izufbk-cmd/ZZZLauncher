package com.example.musicwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.widget.RemoteViews

class MusicWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        manager.updateAppWidget(ids, build(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val c = pickController(context) ?: return
        val tc = c.transportControls
        when (intent.action) {
            ACTION_PLAY_PAUSE ->
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) tc.pause() else tc.play()
            ACTION_NEXT -> tc.skipToNext()
            ACTION_PREV -> tc.skipToPrevious()
        }
    }

    companion object {
        const val AMAZON_MUSIC = "com.amazon.mp3"
        const val ACTION_PLAY_PAUSE = "com.example.musicwidget.PLAY_PAUSE"
        const val ACTION_NEXT = "com.example.musicwidget.NEXT"
        const val ACTION_PREV = "com.example.musicwidget.PREV"

        fun pickController(ctx: Context): MediaController? {
            val msm = ctx.getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(ctx, MusicListenerService::class.java)
            return try {
                val list = msm.getActiveSessions(cn)
                list.firstOrNull { it.packageName == AMAZON_MUSIC } ?: list.firstOrNull()
            } catch (e: SecurityException) {
                null // 通知アクセス未許可
            }
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, MusicWidget::class.java))
            if (ids.isNotEmpty()) mgr.updateAppWidget(ids, build(ctx))
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_player)
            val c = pickController(ctx)
            val md = c?.metadata
            val st = c?.playbackState
            val playing = st?.state == PlaybackState.STATE_PLAYING

            v.setTextViewText(
                R.id.title,
                md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ctx.getString(R.string.nothing_playing)
            )
            v.setTextViewText(
                R.id.artist,
                md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            )

            val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            if (art != null) v.setImageViewBitmap(R.id.art, rounded(scaled(art, 600)))
            else v.setImageViewResource(R.id.art, R.drawable.art_placeholder)

            // 進行バーと時間
            val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            var pos = st?.position ?: 0L
            if (playing && st != null) {
                pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            }
            if (dur > 0) pos = pos.coerceIn(0, dur)
            val progress = if (dur > 0) (pos * 1000 / dur).toInt() else 0
            v.setProgressBar(R.id.progress, 1000, progress, false)
            v.setTextViewText(R.id.time_pos, fmt(pos))
            v.setTextViewText(R.id.time_len, if (dur > 0) fmt(dur) else "0:00")

            v.setImageViewResource(R.id.btn_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
            v.setOnClickPendingIntent(R.id.btn_play, action(ctx, ACTION_PLAY_PAUSE, 1))
            v.setOnClickPendingIntent(R.id.btn_next, action(ctx, ACTION_NEXT, 2))
            v.setOnClickPendingIntent(R.id.btn_prev, action(ctx, ACTION_PREV, 3))

            // ジャケットをタップで Amazon Music を開く
            ctx.packageManager.getLaunchIntentForPackage(AMAZON_MUSIC)?.let {
                v.setOnClickPendingIntent(
                    R.id.art,
                    PendingIntent.getActivity(ctx, 4, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                )
            }
            return v
        }

        private fun action(ctx: Context, action: String, code: Int): PendingIntent {
            val i = Intent(ctx, MusicWidget::class.java).setAction(action)
            return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        private fun fmt(ms: Long): String {
            val s = ms / 1000
            return "%d:%02d".format(s / 60, s % 60)
        }

        // RemoteViews の容量制限対策で縮小
        private fun scaled(b: Bitmap, max: Int): Bitmap {
            val r = max.toFloat() / maxOf(b.width, b.height)
            return if (r >= 1f) b else Bitmap.createScaledBitmap(b, (b.width * r).toInt(), (b.height * r).toInt(), true)
        }

        private fun rounded(b: Bitmap): Bitmap {
            val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val radius = minOf(b.width, b.height) * 0.05f
            canvas.drawRoundRect(RectF(0f, 0f, b.width.toFloat(), b.height.toFloat()), radius, radius, paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            canvas.drawBitmap(b, 0f, 0f, paint)
            return out
        }
    }
}
