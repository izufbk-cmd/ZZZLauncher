
package com.example.zzzlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class LauncherActivity extends Activity {
    LauncherView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,9,28));
        getWindow().setNavigationBarColor(Color.rgb(8,9,28));
        view = new LauncherView(this);
        setContentView(view);
    }
}

class LauncherView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    Handler handler = new Handler();
    Context ctx;
    boolean archive = false;
    ArrayList<AppInfo> apps = new ArrayList<>();
    float downX, downY;

    int bg = Color.rgb(8,9,28);
    int panel = Color.rgb(19,20,48);
    int panel2 = Color.rgb(24,25,58);
    int line = Color.rgb(58,60,102);
    int white = Color.rgb(242,242,250);
    int muted = Color.rgb(151,153,181);
    int orange = Color.rgb(255,75,37);

    String[] labels = {"X","TikTok","Instagram","Amazon","Calendar","YT Studio",
                       "LINE","Gmail","Chrome","Store","Shopping","Folder 01"};

    LauncherView(Context c) {
        super(c); ctx = c;
        p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2);
        apps = loadApps();
        handler.postDelayed(new Runnable(){ public void run(){ invalidate(); handler.postDelayed(this,1000); }},1000);
    }

    ArrayList<AppInfo> loadApps() {
        ArrayList<AppInfo> out = new ArrayList<>();
        PackageManager pm = ctx.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(i, 0)) {
            if (r.activityInfo.packageName.equals(ctx.getPackageName())) continue;
            AppInfo a = new AppInfo();
            a.label = r.loadLabel(pm).toString();
            a.icon = r.loadIcon(pm);
            a.intent = new Intent(Intent.ACTION_MAIN);
            a.intent.addCategory(Intent.CATEGORY_LAUNCHER);
            a.intent.setComponent(new ComponentName(r.activityInfo.packageName, r.activityInfo.name));
            out.add(a);
        }
        Collections.sort(out, (a,b)->a.label.compareToIgnoreCase(b.label));
        return out;
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        c.drawColor(bg);
        if (archive) drawArchive(c); else drawHome(c);
    }

    void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setTextSize(size);
        p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    void box(Canvas c, float l,float t,float r,float b, boolean selected) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(selected ? Color.rgb(29,30,67) : panel);
        c.drawRoundRect(l,t,r,b,14,14,p);
        stroke.setColor(line);
        c.drawRoundRect(l,t,r,b,14,14,stroke);
    }

    void drawHome(Canvas c) {
        float w=getWidth(), h=getHeight(), m=18;
        txt(c, new SimpleDateFormat("HH:mm").format(new Date()), m, 42, 28, white, true);
        txt(c, new SimpleDateFormat("MMM dd / EEE", Locale.ENGLISH).format(new Date()).toUpperCase(), m, 63, 9, muted, false);
        txt(c, "22°  //  NEW ERIDU", m, 82, 10, muted, false);
        txt(c, "MAIN TERMINAL", w/2-55, 48, 11, orange, true);
        txt(c, "FAIRY ASSISTANT", w-122, 35, 8, muted, false);

        // Fairy ring
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.rgb(62,95,255));
        c.drawCircle(w-62,67,20,p);
        p.setStrokeWidth(2); p.setColor(Color.rgb(255,76,40)); c.drawCircle(w-62,67,10,p);
        txt(c,"FAIRY",w-82,100,8,white,true);

        txt(c,"NETWORK / COVER TERMINAL",m,111,9,orange,true);
        stroke.setColor(orange); stroke.setStrokeWidth(2); c.drawLine(m,117,155,117,stroke);

        float top=130, gap=8;
        float cardW=(w-2*m-2*gap)/3, cardH=57;
        for(int row=0;row<2;row++) for(int col=0;col<3;col++){
            float x=m+col*(cardW+gap), y=top+row*(cardH+gap);
            box(c,x,y,x+cardW,y+cardH,false);
            txt(c,String.format("%02d",row*3+col+1),x+10,y+15,8,orange,true);
            txt(c,labels[row*3+col],x+10,y+35,13,white,true);
            txt(c, col==0 ? "SOCIAL" : col==1 ? "SHORT" : "VISUAL",x+10,y+49,7,muted,false);
        }

        // Music panel
        float musicY=top+2*(cardH+gap)+10;
        box(c,m,musicY,w-86,musicY+142,false);
        txt(c,"APPLE MUSIC",m+12,musicY+19,9,orange,true);
        txt(c,"ReDreaming Angel",m+62,musicY+48,13,white,true);
        txt(c,"SānZ & HOYO-MiX",m+62,musicY+64,8,muted,false);
        p.setColor(Color.rgb(235,74,120)); p.setStyle(Paint.Style.FILL);
        c.drawCircle(m+34,musicY+52,20,p);
        txt(c,"●",m+25,musicY+59,18,Color.WHITE,true);
        stroke.setColor(orange); stroke.setStrokeWidth(4);
        c.drawLine(m+14,musicY+87,w-104,musicY+87,stroke);
        button(c,m+12,musicY+102,m+66,musicY+132,"◀◀");
        button(c,m+74,musicY+102,m+128,musicY+132,"▶");
        button(c,m+136,musicY+102,m+190,musicY+132,"▶▶");

        float side=w-76;
        box(c,side,musicY, w-m, musicY+142,false);
        txt(c,"LEVEL",side+10,musicY+18,8,muted,true);
        for(int i=0;i<6;i++) c.drawRect(side+12,musicY+34+i*15,side+22,musicY+43+i*15,p);

        float bottom=musicY+154;
        String[] bottomLabels={"LINE","GMAIL","CHROME"};
        for(int i=0;i<3;i++){
            float x=m+i*((w-2*m+8)/3), bw=(w-2*m-16)/3;
            box(c,x,bottom,x+bw,bottom+55,false);
            txt(c,bottomLabels[i],x+10,bottom+24,11,white,true);
            txt(c,i==0?"MESSAGE":i==1?"MAIL":"WEB",x+10,bottom+40,7,muted,false);
        }
        txt(c,"SYSTEM STATUS  •  ALL SYSTEMS NOMINAL",m,h-28,8,muted,false);
        txt(c,"≡",w-35,h-25,20,orange,true);
    }

    void button(Canvas c,float l,float t,float r,float b,String s){
        box(c,l,t,r,b,true);
        txt(c,s,l+(r-l)/2-8,t+20,12,white,true);
    }

    void drawArchive(Canvas c){
        float w=getWidth(), h=getHeight(), m=18;
        txt(c,"APPLICATION ARCHIVE",m,38,16,orange,true);
        txt(c,"ALL INSTALLED APPS  /  "+apps.size(),m,57,8,muted,false);
        txt(c,"CLOSE",w-50,38,9,white,true);

        box(c,m,72,w-m,110,false);
        txt(c,"SEARCH APPLICATION / NAME",m+14,95,9,muted,false);

        int cols=3, gap=8;
        float cardW=(w-2*m-2*gap)/3, cardH=68, y0=125;
        for(int i=0;i<apps.size();i++){
            int row=i/cols, col=i%cols;
            float x=m+col*(cardW+gap), y=y0+row*(cardH+gap);
            if(y>h-25) break;
            box(c,x,y,x+cardW,y+cardH,false);
            Drawable d=apps.get(i).icon;
            if(d!=null){ d.setBounds((int)x+8,(int)y+18,(int)x+34,(int)y+44); d.draw(c); }
            txt(c,String.format("%03d",i+1),x+8,y+13,7,orange,true);
            String name=apps.get(i).label;
            if(name.length()>14) name=name.substring(0,14);
            txt(c,name,x+42,y+35,10,white,true);
        }
        txt(c,"◀  BACK TO TERMINAL",m,h-10,8,orange,true);
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){
            float x=e.getX(), y=e.getY();
            if(Math.abs(y-downY)>80){ return true; }
            if(archive){
                if(y<65 && x>getWidth()-100){archive=false;invalidate();return true;}
                int cols=3,gap=8,m=18;
                float cardW=(getWidth()-2*m-2*gap)/3, cardH=68,y0=125;
                int col=(int)((x-m)/(cardW+gap)), row=(int)((y-y0)/(cardH+gap));
                if(col>=0&&col<3&&row>=0){
                    int idx=row*3+col;
                    if(idx<apps.size()){
                        try{ctx.startActivity(apps.get(idx).intent);}catch(Exception ignored){}
                    }
                }
                return true;
            }
            // Open application archive from the bottom-right terminal menu.
            if(x>getWidth()-80 && y>getHeight()-70){archive=true;invalidate();return true;}
            // Tap the top app cards: best-effort package launches by label.
            if(y>=130 && y<260){
                int col=(int)((x-18)/((getWidth()-36-16)/3+8));
                int row=(int)((y-130)/65);
                int idx=row*3+col;
                if(idx>=0 && idx<6) launchByLabel(labels[idx]);
            }
            return true;
        }
        return true;
    }

    void launchByLabel(String label){
        PackageManager pm=ctx.getPackageManager();
        Intent i=new Intent(Intent.ACTION_MAIN,null); i.addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo r:pm.queryIntentActivities(i,0)){
            String n=r.loadLabel(pm).toString().toLowerCase();
            if(n.contains(label.toLowerCase())){
                i.setComponent(new ComponentName(r.activityInfo.packageName,r.activityInfo.name));
                try{ctx.startActivity(i);}catch(Exception ignored){}
                return;
            }
        }
    }

    static class AppInfo{
        String label; Drawable icon; Intent intent;
    }
}
