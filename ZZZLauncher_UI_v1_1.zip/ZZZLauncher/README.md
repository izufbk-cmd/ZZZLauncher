# ZZZ Launcher

ZZZ-style Android launcher prototype. The UI is designed to resemble the supplied terminal screenshots, with adaptive phone/tablet layouts, app cards, Fairy Assistant, music panel, mission queue, quick access cards, and an application archive.

Build with the GitHub Actions workflow in `.github/workflows/build-apk.yml` or extract the project into Android Studio.
