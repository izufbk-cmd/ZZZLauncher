package com.example.zzzlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class LauncherActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(6,7,24));
        getWindow().setNavigationBarColor(Color.rgb(6,7,24));
        getWindow().getDecorView().setSystemUiVisibility(0);
        setContentView(new LauncherView(this));
    }
}

class LauncherView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler handler = new Handler();
    final Context ctx;
    boolean archive = false;
    ArrayList<AppInfo> apps = new ArrayList<>();
    float downX, downY;

    final int bg = Color.rgb(5,6,23);
    final int panel = Color.rgb(15,16,43);
    final int panel2 = Color.rgb(20,21,54);
    final int line = Color.rgb(57,58,103);
    final int brightLine = Color.rgb(91,73,150);
    final int white = Color.rgb(242,243,250);
    final int muted = Color.rgb(133,136,169);
    final int dim = Color.rgb(76,78,112);
    final int orange = Color.rgb(255,78,43);
    final int cyan = Color.rgb(101,168,255);

    String[] slots = {"X", "TikTok", "Instagram", "Amazon", "Calendar", "YT Studio"};
    String[] slotTypes = {"SOCIAL / NETWORK", "SHORT VIDEO", "SOCIAL / VISUAL", "SHOPPING", "SCHEDULE", "CREATOR"};

    LauncherView(Context c) {
        super(c); ctx = c;
        p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        stroke.setStyle(Paint.Style.STROKE);
        apps = loadApps();
        handler.postDelayed(new Runnable(){ public void run(){ invalidate(); handler.postDelayed(this,1000); }},1000);
    }

    ArrayList<AppInfo> loadApps() {
        ArrayList<AppInfo> out = new ArrayList<>();
        PackageManager pm = ctx.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(i, 0)) {
            if (r.activityInfo.packageName.equals(ctx.getPackageName())) continue;
            AppInfo a = new AppInfo();
            a.label = r.loadLabel(pm).toString();
            a.icon = r.loadIcon(pm);
            a.intent = new Intent(Intent.ACTION_MAIN);
            a.intent.addCategory(Intent.CATEGORY_LAUNCHER);
            a.intent.setComponent(new ComponentName(r.activityInfo.packageName, r.activityInfo.name));
            out.add(a);
        }
        Collections.sort(out, (a,b)->a.label.compareToIgnoreCase(b.label));
        return out;
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(bg);
        if (archive) drawArchive(c); else drawHome(c);
    }

    void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size);
        p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    void mono(Canvas c, String s, float x, float y, float size, int color) {
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size);
        p.setTypeface(Typeface.create("monospace", Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    void box(Canvas c, float l,float t,float r,float b, boolean selected) {
        p.setStyle(Paint.Style.FILL); p.setColor(selected ? panel2 : panel);
        c.drawRoundRect(l,t,r,b,12,12,p);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(1.4f);
        stroke.setColor(selected ? brightLine : line);
        c.drawRoundRect(l,t,r,b,12,12,stroke);
    }

    void tinyLine(Canvas c, float x1,float y1,float x2,float y2,int color,float width) {
        stroke.setColor(color); stroke.setStrokeWidth(width); stroke.setStyle(Paint.Style.STROKE);
        c.drawLine(x1,y1,x2,y2,stroke);
    }

    void drawHome(Canvas c) {
        float w=getWidth(), h=getHeight();
        boolean wide = w >= 700 || w > h;
        float m = wide ? 24 : 16;
        float headerH = wide ? 92 : 112;

        // Header / terminal identity
        txt(c, new SimpleDateFormat("HH:mm").format(new Date()), m, 38, wide ? 30 : 28, white, true);
        txt(c, new SimpleDateFormat("EEE / MMM dd").format(new Date()).toUpperCase(), m+2, 56, 8, muted, false);
        mono(c, "NETWORK / COVER TERMINAL", m, 72, 7, orange);
        mono(c, "SYSTEM LINK  //  ONLINE", m, 84, 7, dim);
        txt(c, "MAIN TERMINAL", w/2-48, 25, 8, orange, true);
        txt(c, "FAIRY ASSISTANT", w-104, 24, 7, muted, true);

        // Right-side status cluster
        txt(c, "◉", w-78, 48, 14, white, true);
        txt(c, "▮", w-57, 48, 13, cyan, true);
        txt(c, "15", w-35, 49, 10, white, true);
        mono(c, "LV 06", w-43, 62, 6, muted);

        // Fairy ring
        float fx=w-54, fy=83;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.rgb(75,92,255));
        c.drawCircle(fx,fy,17,p);
        p.setStrokeWidth(1); p.setColor(orange); c.drawCircle(fx,fy,9,p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(89,104,255)); c.drawCircle(fx,fy,3,p);
        mono(c,"FAIRY // 01",fx-34,fy+30,6,muted);

        tinyLine(c,m,headerH-8,w-m,headerH-8,line,1);
        tinyLine(c,m,headerH-8,m+110,headerH-8,orange,2);

        // Six terminal cards
        float top=headerH+7, gap=7;
        int cols=wide ? 3 : 2;
        float cardW=(w-2*m-(cols-1)*gap)/cols;
        float cardH=wide ? 58 : 70;
        for(int i=0;i<6;i++){
            int col=i%cols,row=i/cols;
            float x=m+col*(cardW+gap), y=top+row*(cardH+gap);
            drawAppCard(c,x,y,cardW,cardH,i);
        }

        float cardsBottom=top+((6+cols-1)/cols)*cardH+(((6+cols-1)/cols)-1)*gap;
        float musicY=cardsBottom+9;
        if(!wide && musicY+158 > h-135) musicY=Math.max(cardsBottom+5,h-360);
        drawMusic(c,m,musicY,w-2*m,wide ? 126 : 148);

        float quickY=musicY+(wide ? 135 : 158);
        drawQuick(c,m,quickY,w-2*m,wide ? 58 : 60);

        if(!wide){
            float missionY=quickY+69;
            drawMission(c,m,missionY,w-2*m,64);
        }

        mono(c,"SYSTEM STATUS  •  ALL SYSTEMS NOMINAL",m,h-18,6,muted);
        txt(c,"≡",w-28,h-14,18,orange,true);
    }

    void drawAppCard(Canvas c,float x,float y,float cw,float ch,int index){
        box(c,x,y,x+cw,y+ch,false);
        txt(c,String.format("%02d",index+1),x+8,y+14,7,orange,true);
        AppInfo found=findApp(slots[index]);
        if(found!=null && found.icon!=null){
            int s=(int)Math.min(28,ch-28);
            found.icon.setBounds((int)(x+8),(int)(y+ch/2-s/2),(int)(x+8+s),(int)(y+ch/2+s/2));
            found.icon.draw(c);
        }
        txt(c,slots[index],x+42,y+29,11,white,true);
        mono(c,slotTypes[index],x+42,y+43,5.5f,muted);
        tinyLine(c,x+42,y+ch-11,x+cw-10,y+ch-11,dim,1);
        txt(c,"ACCESS",x+42,y+ch-4,5.5f,dim,false);
    }

    AppInfo findApp(String label){
        String q=label.toLowerCase();
        for(AppInfo a:apps) if(a.label.toLowerCase().contains(q)) return a;
        return null;
    }

    void drawMusic(Canvas c,float x,float y,float width,float height){
        float cover=height-28;
        box(c,x,y,x+width,y+height,false);
        txt(c,"APPLE MUSIC",x+10,y+15,7,orange,true);
        mono(c,"PLAYBACK / MEDIA LINK",x+width-120,y+15,5.5f,muted);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(238,70,119));
        c.drawRoundRect(x+10,y+25,x+10+cover,y+25+cover,8,8,p);
        txt(c,"♪",x+10+cover/2-9,y+25+cover/2+9,28,Color.WHITE,true);
        txt(c,"ReDreaming Angel",x+cover+25,y+47,12,white,true);
        txt(c,"SānZ & HOYO-MiX",x+cover+25,y+63,7,muted,false);
        mono(c,"01:42  /  03:58",x+cover+25,y+78,6,dim);
        tinyLine(c,x+cover+25,y+88,x+width-14,y+88,dim,2);
        tinyLine(c,x+cover+25,y+88,x+cover+100,y+88,orange,2);
        button(c,x+cover+25,y+98,x+cover+72,y+124,"◀◀");
        button(c,x+cover+79,y+98,x+cover+126,y+124,"▶");
        button(c,x+cover+133,y+98,x+cover+180,y+124,"▶▶");
        // Level rail on the far right when there is room
        if(width>500){
            float rx=x+width-28;
            tinyLine(c,rx,y+28,rx,y+height-15,line,2);
            for(int i=0;i<5;i++) tinyLine(c,rx-4,y+34+i*16,rx+4,y+34+i*16,i<3?cyan:dim,2);
        }
    }

    void button(Canvas c,float l,float t,float r,float b,String s){
        box(c,l,t,r,b,true);
        txt(c,s,l+(r-l)/2-7,t+18,9,white,true);
    }

    void drawQuick(Canvas c,float x,float y,float width,float height){
        float gap=7, bw=(width-2*gap)/3;
        String[] names={"LINE","GMAIL","CHROME"};
        String[] subs={"MESSAGE","MAIL","WEB"};
        for(int i=0;i<3;i++){
            float xx=x+i*(bw+gap);
            box(c,xx,y,xx+bw,y+height,false);
            txt(c,names[i],xx+10,y+22,10,white,true);
            mono(c,subs[i],xx+10,y+37,5.5f,muted);
            txt(c,"›",xx+bw-18,y+28,14,orange,true);
        }
    }

    void drawMission(Canvas c,float x,float y,float width,float height){
        box(c,x,y,x+width,y+height,false);
        txt(c,"MISSION QUEUE",x+10,y+16,7,orange,true);
        mono(c,"NEXT OBJECTIVE",x+width-95,y+16,5.5f,muted);
        txt(c,"SYSTEM CHECK / READY",x+10,y+38,9,white,true);
        txt(c,"03",x+width-32,y+39,10,cyan,true);
        tinyLine(c,x+10,y+48,x+width-10,y+48,dim,1);
        mono(c,"ACCESS GRID  //  06 NODES ONLINE",x+10,y+58,5.5f,muted);
    }

    void drawArchive(Canvas c){
        float w=getWidth(), h=getHeight(), m=16;
        txt(c,"APPLICATION ARCHIVE",m,31,15,orange,true);
        mono(c,"MAIN TERMINAL  /  ALL INSTALLED APPS",m,46,6,muted);
        txt(c,"×",w-30,33,20,white,true);
        box(c,m,60,w-m,98,false);
        mono(c,"SEARCH APPLICATION / NAME",m+12,84,7,muted);
        int cols=w>=700?4:3, gap=7;
        float cardW=(w-2*m-(cols-1)*gap)/cols, cardH=62, y0=110;
        for(int i=0;i<apps.size();i++){
            int row=i/cols,col=i%cols;
            float x=m+col*(cardW+gap), y=y0+row*(cardH+gap);
            if(y+cardH>h-25) break;
            box(c,x,y,x+cardW,y+cardH,false);
            Drawable d=apps.get(i).icon;
            if(d!=null){ d.setBounds((int)x+8,(int)y+18,(int)x+34,(int)y+44); d.draw(c); }
            mono(c,String.format("%03d",i+1),x+8,y+12,5.5f,orange);
            String name=apps.get(i).label;
            if(name.length()>14) name=name.substring(0,14);
            txt(c,name,x+42,y+35,9,white,true);
            mono(c,"LAUNCH",x+42,y+49,5.5f,muted);
        }
        mono(c,"‹  BACK TO MAIN TERMINAL",m,h-9,6,orange);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){
            float x=e.getX(), y=e.getY(), w=getWidth(), h=getHeight();
            if(Math.abs(y-downY)>80) return true;
            if(archive){
                if((y<60 && x>w-90) || (y>h-50)){archive=false;invalidate();return true;}
                int m=16,gap=7,cols=w>=700?4:3;
                float cardW=(w-2*m-(cols-1)*gap)/cols, cardH=62,y0=110;
                int col=(int)((x-m)/(cardW+gap)), row=(int)((y-y0)/(cardH+gap));
                if(col>=0&&col<cols&&row>=0){
                    int idx=row*cols+col;
                    if(idx<apps.size()) try{ctx.startActivity(apps.get(idx).intent);}catch(Exception ignored){}
                }
                return true;
            }
            if(x>w-70 && y>h-70){archive=true;invalidate();return true;}
            float m=w>=700||w>h?24:16, headerH=w>=700||w>h?92:112, gap=7;
            int cols=w>=700||w>h?3:2;
            float cardW=(w-2*m-(cols-1)*gap)/cols, cardH=w>=700||w>h?58:70, top=headerH+7;
            if(y>=top && y<top+3*(cardH+gap)){
                int col=(int)((x-m)/(cardW+gap)), row=(int)((y-top)/(cardH+gap));
                int idx=row*cols+col;
                if(col>=0&&col<cols&&row>=0&&idx<6) launchByLabel(slots[idx]);
            }
            return true;
        }
        return true;
    }

    void launchByLabel(String label){
        PackageManager pm=ctx.getPackageManager();
        Intent i=new Intent(Intent.ACTION_MAIN,null); i.addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo r:pm.queryIntentActivities(i,0)){
            String n=r.loadLabel(pm).toString().toLowerCase();
            if(n.contains(label.toLowerCase())){
                i.setComponent(new ComponentName(r.activityInfo.packageName,r.activityInfo.name));
                try{ctx.startActivity(i);}catch(Exception ignored){} return;
            }
        }
    }

    static class AppInfo{ String label; Drawable icon; Intent intent; }
}
