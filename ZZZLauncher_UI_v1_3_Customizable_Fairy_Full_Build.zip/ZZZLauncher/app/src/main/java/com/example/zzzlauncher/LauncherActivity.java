package com.example.zzzlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.*;
import android.app.AlertDialog;
import android.net.Uri;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class LauncherActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(6,7,24));
        getWindow().setNavigationBarColor(Color.rgb(6,7,24));
        getWindow().getDecorView().setSystemUiVisibility(0);
        setContentView(new LauncherView(this));
    }
}

class LauncherView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler handler = new Handler();
    final Context ctx;
    boolean archive = false;
    ArrayList<AppInfo> apps = new ArrayList<>();
    float downX, downY, downTime;

    final int bg = Color.rgb(5,6,23);
    final int panel = Color.rgb(15,16,43);
    final int panel2 = Color.rgb(20,21,54);
    final int line = Color.rgb(57,58,103);
    final int brightLine = Color.rgb(91,73,150);
    final int white = Color.rgb(242,243,250);
    final int muted = Color.rgb(133,136,169);
    final int dim = Color.rgb(76,78,112);
    final int orange = Color.rgb(255,78,43);
    final int cyan = Color.rgb(101,168,255);

    final String[] defaultSlots = {"X", "TikTok", "Instagram", "Amazon", "Calendar", "YT Studio"};
    final String[] slotTypes = {"SOCIAL / NETWORK", "SHORT VIDEO", "SOCIAL / VISUAL", "SHOPPING", "SCHEDULE", "CREATOR"};
    String[] slots = new String[6];
    final android.content.SharedPreferences prefs;

    LauncherView(Context c) {
        super(c); ctx = c;
        prefs = ctx.getSharedPreferences("launcher_settings", Context.MODE_PRIVATE);
        p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        stroke.setStyle(Paint.Style.STROKE);
        apps = loadApps();
        loadSlotSettings();
        handler.postDelayed(new Runnable(){ public void run(){ invalidate(); handler.postDelayed(this,1000); }},1000);
    }

    void loadSlotSettings() {
        for (int i=0; i<slots.length; i++) {
            slots[i] = prefs.getString("slot_" + i, defaultSlots[i]);
        }
    }

    void saveSlot(int index, String label) {
        slots[index] = label;
        prefs.edit().putString("slot_" + index, label).apply();
        invalidate();
    }

    ArrayList<AppInfo> loadApps() {
        ArrayList<AppInfo> out = new ArrayList<>();
        PackageManager pm = ctx.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(i, 0)) {
            if (r.activityInfo.packageName.equals(ctx.getPackageName())) continue;
            AppInfo a = new AppInfo();
            a.label = r.loadLabel(pm).toString();
            a.icon = r.loadIcon(pm);
            a.intent = new Intent(Intent.ACTION_MAIN);
            a.intent.addCategory(Intent.CATEGORY_LAUNCHER);
            a.intent.setComponent(new ComponentName(r.activityInfo.packageName, r.activityInfo.name));
            out.add(a);
        }
        Collections.sort(out, (a,b)->a.label.compareToIgnoreCase(b.label));
        return out;
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(bg);
        if (archive) drawArchive(c); else drawHome(c);
    }

    void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size);
        p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    void mono(Canvas c, String s, float x, float y, float size, int color) {
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size);
        p.setTypeface(Typeface.create("monospace", Typeface.NORMAL));
        c.drawText(s, x, y, p);
    }

    void box(Canvas c, float l,float t,float r,float b, boolean selected) {
        p.setStyle(Paint.Style.FILL); p.setColor(selected ? panel2 : panel);
        c.drawRoundRect(l,t,r,b,12,12,p);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(1.4f);
        stroke.setColor(selected ? brightLine : line);
        c.drawRoundRect(l,t,r,b,12,12,stroke);
    }

    void tinyLine(Canvas c, float x1,float y1,float x2,float y2,int color,float width) {
        stroke.setColor(color); stroke.setStrokeWidth(width); stroke.setStyle(Paint.Style.STROKE);
        c.drawLine(x1,y1,x2,y2,stroke);
    }

    void drawHome(Canvas c) {
        float w=getWidth(), h=getHeight();
        boolean wide = w >= 700 || w > h;
        float m = wide ? 24 : 18;

        // On tall phones, deliberately distribute the interface vertically instead of
        // packing everything into the top area. This keeps the terminal feel while
        // making the whole display useful.
        float headerH = wide ? 92 : Math.max(150, h * 0.13f);
        float top = headerH + (wide ? 7 : 12);
        float bottomReserve = wide ? 34 : 34;

        txt(c, new SimpleDateFormat("HH:mm").format(new Date()), m, wide ? 38 : 62, wide ? 30 : 44, white, true);
        txt(c, new SimpleDateFormat("EEE / MMM dd").format(new Date()).toUpperCase(), m+2, wide ? 56 : 84, wide ? 8 : 10, muted, false);
        mono(c, "NETWORK / COVER TERMINAL", m, wide ? 72 : 105, wide ? 7 : 8, orange);
        mono(c, "SYSTEM LINK  //  ONLINE", m, wide ? 84 : 118, wide ? 7 : 8, dim);
        txt(c, "MAIN TERMINAL", w/2-58, wide ? 25 : 24, wide ? 8 : 10, orange, true);
        txt(c, "FAIRY ASSISTANT", w-126, wide ? 24 : 24, wide ? 7 : 8, muted, true);

        txt(c, "◉", w-92, wide ? 48 : 62, 16, white, true);
        txt(c, "▮", w-68, wide ? 48 : 62, 14, cyan, true);
        txt(c, "15", w-42, wide ? 49 : 63, 11, white, true);
        mono(c, "LV 06", w-50, wide ? 62 : 80, 7, muted);

        float fx=w-62, fy=wide ? 83 : 108;
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3); p.setColor(Color.rgb(75,92,255));
        c.drawCircle(fx,fy,19,p);
        p.setStrokeWidth(1); p.setColor(orange); c.drawCircle(fx,fy,10,p);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(89,104,255)); c.drawCircle(fx,fy,3,p);
        mono(c,"FAIRY // 01",fx-38,fy+31,6,muted);

        tinyLine(c,m,headerH-8,w-m,headerH-8,line,1);
        tinyLine(c,m,headerH-8,m+(wide?110:170),headerH-8,orange,2);

        int cols=wide ? 3 : 2;
        float gap=wide ? 7 : 9;
        float cardW=(w-2*m-(cols-1)*gap)/cols;
        float cardH;
        if(wide) cardH=58;
        else {
            float available = h * 0.24f;
            cardH = Math.max(78, Math.min(118, (available-gap)/3f));
        }
        for(int i=0;i<6;i++){
            int col=i%cols,row=i/cols;
            float x=m+col*(cardW+gap), y=top+row*(cardH+gap);
            drawAppCard(c,x,y,cardW,cardH,i);
        }
        float cardsBottom=top+3*cardH+2*gap;

        float musicY, musicH;
        if(wide){
            musicY=cardsBottom+9;
            musicH=126;
        } else {
            musicY=Math.max(cardsBottom+16, h*0.39f);
            musicH=Math.max(190, Math.min(290, h*0.22f));
        }
        drawMusic(c,m,musicY,w-2*m,musicH);

        float quickY=musicY+musicH+(wide ? 9 : 16);
        float quickH=wide ? 58 : Math.max(82, Math.min(120,h*0.08f));
        drawQuick(c,m,quickY,w-2*m,quickH);

        if(!wide){
            float missionY=quickY+quickH+16;
            float missionH=Math.max(100, Math.min(150,h*0.10f));
            drawMission(c,m,missionY,w-2*m,missionH);
        }

        mono(c,"SYSTEM STATUS  •  ALL SYSTEMS NOMINAL",m,h-18,6,muted);
        txt(c,"≡",w-28,h-14,18,orange,true);
    }

    void drawAppCard(Canvas c,float x,float y,float cw,float ch,int index){
        box(c,x,y,x+cw,y+ch,false);
        txt(c,String.format("%02d",index+1),x+8,y+14,7,orange,true);
        AppInfo found=findApp(slots[index]);
        if(found!=null && found.icon!=null){
            int s=(int)Math.min(28,ch-28);
            found.icon.setBounds((int)(x+8),(int)(y+ch/2-s/2),(int)(x+8+s),(int)(y+ch/2+s/2));
            found.icon.draw(c);
        }
        String display = slots[index];
        if ("EMPTY".equals(display)) display = "SET APP";
        txt(c,display,x+42,y+29,11,white,true);
        mono(c,slotTypes[index] + "  /  LONG PRESS = SET",x+42,y+43,5.0f,muted);
        tinyLine(c,x+42,y+ch-11,x+cw-10,y+ch-11,dim,1);
        txt(c,"ACCESS",x+42,y+ch-4,5.5f,dim,false);
    }

    AppInfo findApp(String label){
        if ("EMPTY".equals(label)) return null;
        String q=label.toLowerCase();
        for(AppInfo a:apps) if(a.label.toLowerCase().contains(q)) return a;
        return null;
    }

    void drawMusic(Canvas c,float x,float y,float width,float height){
        float cover=Math.min(height-28, width*0.30f);
        box(c,x,y,x+width,y+height,false);
        txt(c,"APPLE MUSIC",x+10,y+15,7,orange,true);
        mono(c,"PLAYBACK / MEDIA LINK",x+width-120,y+15,5.5f,muted);
        p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(238,70,119));
        c.drawRoundRect(x+10,y+25,x+10+cover,y+25+cover,8,8,p);
        txt(c,"♪",x+10+cover/2-9,y+25+cover/2+9,28,Color.WHITE,true);
        txt(c,"ReDreaming Angel",x+cover+25,y+47,Math.min(14, Math.max(10,width*0.018f)),white,true);
        txt(c,"SānZ & HOYO-MiX",x+cover+25,y+63,7,muted,false);
        mono(c,"01:42  /  03:58",x+cover+25,y+78,6,dim);
        tinyLine(c,x+cover+25,y+88,x+width-14,y+88,dim,2);
        tinyLine(c,x+cover+25,y+88,x+cover+100,y+88,orange,2);
        button(c,x+cover+25,y+98,x+cover+72,y+124,"◀◀");
        button(c,x+cover+79,y+98,x+cover+126,y+124,"▶");
        button(c,x+cover+133,y+98,x+cover+180,y+124,"▶▶");
        // Level rail on the far right when there is room
        if(width>500){
            float rx=x+width-28;
            tinyLine(c,rx,y+28,rx,y+height-15,line,2);
            for(int i=0;i<5;i++) tinyLine(c,rx-4,y+34+i*16,rx+4,y+34+i*16,i<3?cyan:dim,2);
        }
    }

    void button(Canvas c,float l,float t,float r,float b,String s){
        box(c,l,t,r,b,true);
        txt(c,s,l+(r-l)/2-7,t+18,9,white,true);
    }

    void drawQuick(Canvas c,float x,float y,float width,float height){
        float gap=7, bw=(width-2*gap)/3;
        String[] names={"LINE","GMAIL","CHROME"};
        String[] subs={"MESSAGE","MAIL","WEB"};
        for(int i=0;i<3;i++){
            float xx=x+i*(bw+gap);
            box(c,xx,y,xx+bw,y+height,false);
            txt(c,names[i],xx+10,y+height*0.42f,10,white,true);
            mono(c,subs[i],xx+10,y+height*0.68f,5.5f,muted);
            txt(c,"›",xx+bw-18,y+height*0.52f,14,orange,true);
        }
    }

    void drawMission(Canvas c,float x,float y,float width,float height){
        box(c,x,y,x+width,y+height,false);
        txt(c,"MISSION QUEUE",x+10,y+16,7,orange,true);
        mono(c,"NEXT OBJECTIVE",x+width-95,y+16,5.5f,muted);
        txt(c,"SYSTEM CHECK / READY",x+10,y+height*0.48f,10,white,true);
        txt(c,"03",x+width-32,y+height*0.49f,11,cyan,true);
        tinyLine(c,x+10,y+height*0.62f,x+width-10,y+height*0.62f,dim,1);
        mono(c,"ACCESS GRID  //  06 NODES ONLINE",x+10,y+height*0.82f,5.5f,muted);
    }

    void drawArchive(Canvas c){
        float w=getWidth(), h=getHeight(), m=16;
        txt(c,"APPLICATION ARCHIVE",m,31,15,orange,true);
        mono(c,"MAIN TERMINAL  /  ALL INSTALLED APPS",m,46,6,muted);
        txt(c,"×",w-30,33,20,white,true);
        box(c,m,60,w-m,98,false);
        mono(c,"SEARCH APPLICATION / NAME",m+12,84,7,muted);
        int cols=w>=700?4:3, gap=7;
        float cardW=(w-2*m-(cols-1)*gap)/cols, cardH=62, y0=110;
        for(int i=0;i<apps.size();i++){
            int row=i/cols,col=i%cols;
            float x=m+col*(cardW+gap), y=y0+row*(cardH+gap);
            if(y+cardH>h-25) break;
            box(c,x,y,x+cardW,y+cardH,false);
            Drawable d=apps.get(i).icon;
            if(d!=null){ d.setBounds((int)x+8,(int)y+18,(int)x+34,(int)y+44); d.draw(c); }
            mono(c,String.format("%03d",i+1),x+8,y+12,5.5f,orange);
            String name=apps.get(i).label;
            if(name.length()>14) name=name.substring(0,14);
            txt(c,name,x+42,y+35,9,white,true);
            mono(c,"LAUNCH",x+42,y+49,5.5f,muted);
        }
        mono(c,"‹  BACK TO MAIN TERMINAL",m,h-9,6,orange);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();downTime=System.currentTimeMillis();return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){
            float x=e.getX(), y=e.getY(), w=getWidth(), h=getHeight();
            if(Math.abs(y-downY)>80) return true;
            if(archive){
                if((y<60 && x>w-90) || (y>h-50)){archive=false;invalidate();return true;}
                int m=16,gap=7,cols=w>=700?4:3;
                float cardW=(w-2*m-(cols-1)*gap)/cols, cardH=62,y0=110;
                int col=(int)((x-m)/(cardW+gap)), row=(int)((y-y0)/(cardH+gap));
                if(col>=0&&col<cols&&row>=0){
                    int idx=row*cols+col;
                    if(idx<apps.size()) try{ctx.startActivity(apps.get(idx).intent);}catch(Exception ignored){}
                }
                return true;
            }
            // FAIRY ASSISTANT: tap the ring to open the ChatGPT app, or the web version.
            float fairyX = w - 62;
            float fairyY = (w>=700 || w>h) ? 83 : 108;
            if (Math.hypot(x - fairyX, y - fairyY) < 34) {
                openFairyAI();
                return true;
            }

            if(x>w-70 && y>h-70){archive=true;invalidate();return true;}
            float m=w>=700||w>h?24:16, headerH=w>=700||w>h?92:112, gap=7;
            int cols=w>=700||w>h?3:2;
            float cardW=(w-2*m-(cols-1)*gap)/cols, cardH=w>=700||w>h?58:70, top=headerH+7;
            if(y>=top && y<top+3*(cardH+gap)){
                int col=(int)((x-m)/(cardW+gap)), row=(int)((y-top)/(cardH+gap));
                int idx=row*cols+col;
                if(col>=0&&col<cols&&row>=0&&idx<6) {
                    if (System.currentTimeMillis() - downTime > 500) {
                        showAppPicker(idx);
                    } else {
                        launchByLabel(slots[idx]);
                    }
                }
            }
            return true;
        }
        return true;
    }

    void showAppPicker(final int slotIndex) {
        final ArrayList<AppInfo> choices = loadApps();
        String[] names = new String[choices.size() + 1];
        names[0] = "未設定（空きスロット）";
        for (int i = 0; i < choices.size(); i++) names[i + 1] = choices.get(i).label;

        AlertDialog dialog = new AlertDialog.Builder(ctx)
                .setTitle("APP SLOT " + String.format("%02d", slotIndex + 1) + " を設定")
                .setItems(names, (d, which) -> {
                    if (which == 0) {
                        saveSlot(slotIndex, "EMPTY");
                    } else {
                        saveSlot(slotIndex, choices.get(which - 1).label);
                    }
                })
                .setNegativeButton("キャンセル", null)
                .create();
        dialog.show();
    }

    void openFairyAI() {
        PackageManager pm = ctx.getPackageManager();

        // Prefer the installed ChatGPT app.
        Intent launch = pm.getLaunchIntentForPackage("com.openai.chatgpt");
        if (launch != null) {
            try {
                ctx.startActivity(launch);
                return;
            } catch (Exception ignored) {}
        }

        // Fallback: find an installed launcher app named ChatGPT.
        Intent i = new Intent(Intent.ACTION_MAIN, null);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo r : pm.queryIntentActivities(i, 0)) {
            String name = r.loadLabel(pm).toString();
            if (name.toLowerCase().contains("chatgpt")) {
                i.setComponent(new ComponentName(r.activityInfo.packageName, r.activityInfo.name));
                try {
                    ctx.startActivity(i);
                    return;
                } catch (Exception ignored) {}
            }
        }

        // Final fallback: open ChatGPT in the browser.
        try {
            ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/")));
        } catch (Exception ignored) {}
    }

    void launchByLabel(String label){
        PackageManager pm=ctx.getPackageManager();
        Intent i=new Intent(Intent.ACTION_MAIN,null); i.addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo r:pm.queryIntentActivities(i,0)){
            String n=r.loadLabel(pm).toString().toLowerCase();
            if(n.contains(label.toLowerCase())){
                i.setComponent(new ComponentName(r.activityInfo.packageName,r.activityInfo.name));
                try{ctx.startActivity(i);}catch(Exception ignored){} return;
            }
        }
    }

    static class AppInfo{ String label; Drawable icon; Intent intent; }
}
