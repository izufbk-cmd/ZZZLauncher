package com.example.zzzlauncher;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.os.*;
import android.provider.CalendarContract;
import android.provider.Settings;
import android.view.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class LauncherActivity extends Activity {
    LauncherView launcherView;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(6,7,24));
        getWindow().setNavigationBarColor(Color.rgb(6,7,24));
        launcherView = new LauncherView(this);
        setContentView(launcherView);
    }
    @Override public void onBackPressed() {
        if (launcherView != null && launcherView.archive) { launcherView.archive=false; launcherView.invalidate(); }
        else { /* keep launcher on the home screen */ }
    }
    void requestPermission(String permission, int code) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{permission}, code);
    }
}

class LauncherView extends View {
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Handler handler = new Handler(Looper.getMainLooper());
    final LauncherActivity activity;
    final AudioManager audio;
    boolean archive=false;
    ArrayList<AppInfo> apps=new ArrayList<>();
    float downX,downY; long downTime;
    final int bg=Color.rgb(5,6,23), panel=Color.rgb(15,16,43), panel2=Color.rgb(20,21,54);
    final int line=Color.rgb(57,58,103), brightLine=Color.rgb(91,73,150), white=Color.rgb(242,243,250);
    final int muted=Color.rgb(133,136,169), dim=Color.rgb(76,78,112), orange=Color.rgb(255,78,43), cyan=Color.rgb(101,168,255);
    final String[] defaultSlots={"YouTube","TikTok","Instagram","Amazon","Calendar","Chrome"};
    final String[] slotTypes={"VIDEO / MEDIA","SHORT VIDEO","SOCIAL / VISUAL","SHOPPING","SCHEDULE","WEB"};
    String[] slots=new String[6];
    final SharedPreferences prefs;
    String weather="WEATHER / TAP TO LOAD";
    String temperature="--°";
    String calendarLine="CALENDAR / TAP TO LOAD";
    Bitmap albumArt;
    String mediaTitle="No active media";
    String mediaArtist="MEDIA LINK";
    boolean mediaPlaying=false;

    LauncherView(LauncherActivity c){
        super(c); activity=c; audio=(AudioManager)c.getSystemService(Context.AUDIO_SERVICE);
        prefs=c.getSharedPreferences("launcher_settings",Context.MODE_PRIVATE);
        stroke.setStyle(Paint.Style.STROKE); apps=loadApps(); loadSlotSettings();
        handler.postDelayed(new Runnable(){public void run(){
            refreshMedia(); invalidate(); handler.postDelayed(this,1000);
        }},500);
    }
    void loadSlotSettings(){for(int i=0;i<slots.length;i++) slots[i]=prefs.getString("slot_"+i,defaultSlots[i]);}
    void saveSlot(int i,String s){slots[i]=s;prefs.edit().putString("slot_"+i,s).apply();invalidate();}
    ArrayList<AppInfo> loadApps(){
        ArrayList<AppInfo> out=new ArrayList<>(); PackageManager pm=activity.getPackageManager();
        Intent i=new Intent(Intent.ACTION_MAIN,null);i.addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo r:pm.queryIntentActivities(i,0)){
            if(r.activityInfo.packageName.equals(activity.getPackageName()))continue;
            AppInfo a=new AppInfo();a.label=r.loadLabel(pm).toString();a.icon=r.loadIcon(pm);
            a.intent=new Intent(Intent.ACTION_MAIN);a.intent.addCategory(Intent.CATEGORY_LAUNCHER);
            a.intent.setComponent(new ComponentName(r.activityInfo.packageName,r.activityInfo.name));out.add(a);
        }
        Collections.sort(out,(a,b)->a.label.compareToIgnoreCase(b.label));return out;
    }
    AppInfo findApp(String label){for(AppInfo a:apps)if(a.label.equalsIgnoreCase(label)||a.label.toLowerCase().contains(label.toLowerCase()))return a;return null;}

    @Override protected void onDraw(Canvas c){c.drawColor(bg);if(archive)drawArchive(c);else drawHome(c);}
    void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(s,x,y,p);}
    void mono(Canvas c,String s,float x,float y,float size,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("monospace",Typeface.NORMAL));c.drawText(s,x,y,p);}
    void box(Canvas c,float l,float t,float r,float b,boolean selected){p.setStyle(Paint.Style.FILL);p.setColor(selected?panel2:panel);c.drawRoundRect(l,t,r,b,12,12,p);stroke.setStrokeWidth(1.4f);stroke.setColor(selected?brightLine:line);c.drawRoundRect(l,t,r,b,12,12,stroke);}
    void line(Canvas c,float x1,float y1,float x2,float y2,int color,float width){stroke.setColor(color);stroke.setStrokeWidth(width);c.drawLine(x1,y1,x2,y2,stroke);}

    void drawHome(Canvas c){
        float w=getWidth(),h=getHeight(),m=w>=700?24:18,gap=w>=700?10:Math.max(8,h*.008f);
        boolean wide=w>=700||w>h;
        float headerH=wide?92:Math.max(118,h*.12f), top=headerH+(wide?10:h*.012f);
        txt(c,new SimpleDateFormat("HH:mm").format(new Date()),m,wide?38:headerH*.48f,wide?30:Math.max(42,h*.028f),white,true);
        txt(c,new SimpleDateFormat("EEE / MMM dd").format(new Date()).toUpperCase(),m+2,wide?56:headerH*.67f,wide?8:10,muted,false);
        mono(c,"NETWORK / COVER TERMINAL",m,wide?72:headerH*.82f,8,orange);
        txt(c,"MAIN TERMINAL",w/2-58,wide?25:24,9,orange,true);
        txt(c,"FAIRY ASSISTANT",w-126,wide?24:24,8,muted,true);
        float fx=w-62,fy=wide?83:headerH*.86f;
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(75,92,255));c.drawCircle(fx,fy,19,p);p.setStrokeWidth(1);p.setColor(orange);c.drawCircle(fx,fy,10,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(89,104,255));c.drawCircle(fx,fy,3,p);mono(c,"AI",fx-7,fy+31,6,muted);
        line(c,m,headerH-8,w-m,headerH-8,line,1);

        int cols=wide?3:2;float cardW=(w-2*m-(cols-1)*gap)/cols;float cardArea=wide?174:h*.285f;float cardH=wide?58:Math.max(78,(cardArea-2*gap)/3f);
        for(int i=0;i<6;i++){int col=i%cols,row=i/cols;drawAppCard(c,m+col*(cardW+gap),top+row*(cardH+gap),cardW,cardH,i);}
        float cardsBottom=top+3*cardH+2*gap;
        float musicY=cardsBottom+(wide?10:h*.018f);float musicH=wide?126:Math.max(175,Math.min(h*.23f,h-musicY-h*.27f));
        drawMusic(c,m,musicY,w-2*m,musicH);
        float lower=musicY+musicH+(wide?10:h*.018f);float quickH=wide?58:Math.max(78,Math.min(h*.10f,h*.12f));drawQuick(c,m,lower,w-2*m,quickH);
        if(!wide){float my=lower+quickH+h*.018f;float mh=Math.max(90,Math.min(h*.13f,h-my-30));drawInfo(c,m,my,w-2*m,mh);}
        mono(c,"SYSTEM STATUS  •  HOME / READY",m,h-18,6,muted);txt(c,"≡",w-28,h-14,18,orange,true);
    }

    void drawAppCard(Canvas c,float x,float y,float cw,float ch,int index){
        box(c,x,y,x+cw,y+ch,false);txt(c,String.format("%02d",index+1),x+8,y+14,7,orange,true);
        AppInfo found=findApp(slots[index]);if(found!=null&&found.icon!=null){int s=(int)Math.min(28,ch-28);found.icon.setBounds((int)x+8,(int)(y+ch/2-s/2),(int)x+8+s,(int)(y+ch/2+s/2));found.icon.draw(c);}
        txt(c,"EMPTY".equals(slots[index])?"SET APP":slots[index],x+42,y+29,11,white,true);mono(c,slotTypes[index],x+42,y+43,5.5f,muted);line(c,x+42,y+ch-11,x+cw-10,y+ch-11,dim,1);txt(c,"LONG PRESS = SET",x+42,y+ch-4,5.2f,dim,false);
    }

    void drawMusic(Canvas c,float x,float y,float width,float height){
        box(c,x,y,x+width,y+height,false);txt(c,"MEDIA LINK",x+10,y+15,7,orange,true);
        float cover=Math.min(height-38,Math.max(58,width*.22f));float cx=x+10,cy=y+25;
        p.setStyle(Paint.Style.FILL);p.setColor(panel2);c.drawRoundRect(cx,cy,cx+cover,cy+cover,8,8,p);
        if(albumArt!=null){RectF dst=new RectF(cx,cy,cx+cover,cy+cover);c.drawBitmap(albumArt,null,dst,p);}else{txt(c,"♪",cx+cover/2-10,cy+cover/2+10,28,white,true);}
        txt(c,clip(mediaTitle,24),x+cover+25,y+47,Math.min(14,Math.max(10,width*.018f)),white,true);
        txt(c,clip(mediaArtist,24),x+cover+25,y+63,7,muted,false);
        mono(c,mediaPlaying?"PLAYING / ACTIVE SESSION":"NO ACTIVE SESSION",x+cover+25,y+79,6,mediaPlaying?cyan:dim);
        int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),cur=audio.getStreamVolume(AudioManager.STREAM_MUSIC);float barL=x+cover+25,barR=x+width-15,barY=y+92;
        line(c,barL,barY,barR,barY,dim,4);line(c,barL,barY,barL+(barR-barL)*(max==0?0:(float)cur/max),barY,orange,4);p.setStyle(Paint.Style.FILL);p.setColor(white);c.drawCircle(barL+(barR-barL)*(max==0?0:(float)cur/max),barY,7,p);
        mono(c,"VOLUME  "+cur+" / "+max,barL,y+110,6,muted);
        txt(c,mediaPlaying?"Ⅱ":"▶",barR-18,y+129,12,white,true);
        mono(c,"TAP BAR = VOLUME   •   TAP ART = MEDIA",x+10,y+height-9,5.5f,dim);
    }
    String clip(String s,int n){return s.length()>n?s.substring(0,n-1)+"…":s;}

    void drawQuick(Canvas c,float x,float y,float width,float height){float gap=7,bw=(width-2*gap)/3;String[] names={"LINE","GMAIL","CHROME"};for(int i=0;i<3;i++){float xx=x+i*(bw+gap);box(c,xx,y,xx+bw,y+height,false);txt(c,names[i],xx+10,y+height*.42f,10,white,true);mono(c,"QUICK ACCESS",xx+10,y+height*.68f,5.5f,muted);txt(c,"›",xx+bw-18,y+height*.52f,14,orange,true);}}
    void drawInfo(Canvas c,float x,float y,float width,float height){box(c,x,y,x+width,y+height,false);txt(c,"WEATHER",x+10,y+17,7,orange,true);txt(c,temperature,x+10,y+48,24,white,true);mono(c,clip(weather,24),x+70,y+47,7,muted);txt(c,"CALENDAR",x+10,y+70,7,orange,true);mono(c,clip(calendarLine,45),x+10,y+86,6,muted);mono(c,"TAP WEATHER / CALENDAR TO UPDATE",x+10,y+height-8,5,dim);}

    void drawArchive(Canvas c){float w=getWidth(),h=getHeight(),m=16;txt(c,"APPLICATION ARCHIVE",m,31,15,orange,true);mono(c,"ALL INSTALLED APPS  /  LONG PRESS = SET SLOT",m,46,6,muted);txt(c,"×",w-30,33,20,white,true);box(c,m,60,w-m,98,false);mono(c,"SEARCH APPLICATION / NAME",m+12,84,7,muted);int cols=w>=700?4:3,gap=7;float cw=(w-2*m-(cols-1)*gap)/cols,ch=62,y0=110;for(int i=0;i<apps.size();i++){int row=i/cols,col=i%cols;float x=m+col*(cw+gap),y=y0+row*(ch+gap);if(y+ch>h-25)break;box(c,x,y,x+cw,y+ch,false);Drawable d=apps.get(i).icon;if(d!=null){d.setBounds((int)x+8,(int)y+18,(int)x+34,(int)y+44);d.draw(c);}mono(c,String.format("%03d",i+1),x+8,y+12,5.5f,orange);txt(c,clip(apps.get(i).label,14),x+42,y+35,9,white,true);mono(c,"LAUNCH",x+42,y+49,5.5f,muted);}}

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();downTime=System.currentTimeMillis();return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(archive){if((y<60&&x>w-90)||(y>h-50)){archive=false;invalidate();return true;}int m=16,g=7,cols=w>=700?4:3;float cw=(w-2*m-(cols-1)*g)/cols,ch=62,y0=110;int col=(int)((x-m)/(cw+g)),row=(int)((y-y0)/(ch+g));int idx=row*cols+col;if(col>=0&&col<cols&&row>=0&&idx<apps.size())try{activity.startActivity(apps.get(idx).intent);}catch(Exception ignored){}return true;}
            boolean wide=w>=700||w>h;float headerH=wide?92:Math.max(118,h*.12f);float fx=w-62,fy=wide?83:headerH*.86f;if(Math.hypot(x-fx,y-fy)<34){openFairyAI();return true;}
            if(x>w-70&&y>h-70){archive=true;invalidate();return true;}
            float m=wide?24:18,gap=wide?10:Math.max(8,h*.008f);int cols=wide?3:2;float cardW=(w-2*m-(cols-1)*gap)/cols,cardArea=wide?174:h*.285f,cardH=wide?58:Math.max(78,(cardArea-2*gap)/3f),top=headerH+(wide?10:h*.012f);
            if(y>=top&&y<top+3*(cardH+gap)){int col=(int)((x-m)/(cardW+gap)),row=(int)((y-top)/(cardH+gap)),idx=row*cols+col;if(col>=0&&col<cols&&row>=0&&idx<6){if(System.currentTimeMillis()-downTime>500)showAppPicker(idx);else launchByLabel(slots[idx]);return true;}}
            // Music volume bar
            float cardsBottom=top+3*cardH+2*gap,musicY=cardsBottom+(wide?10:h*.018f),musicH=wide?126:Math.max(175,Math.min(h*.23f,h-musicY-h*.27f));float cover=Math.min(musicH-38,Math.max(58,(w-2*m)*.22f));float barL=m+10+cover+25,barR=w-m-15,barY=musicY+92;if(y>barY-20&&y<barY+20&&x>barL&&x<barR){int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);int v=Math.round((x-barL)/(barR-barL)*max);audio.setStreamVolume(AudioManager.STREAM_MUSIC,Math.max(0,Math.min(max,v)),0);invalidate();return true;}
            // Quick-access cards
            float qy=lower, qh=wide?58:Math.max(78,Math.min(h*.10f,h*.12f));
            if(y>qy&&y<qy+qh){
                int qi=(int)((x-m)/((w-2*m+7)/3f));
                String[] qnames={"LINE","GMAIL","CHROME"};
                if(qi>=0&&qi<3){launchByLabel(qnames[qi]);return true;}
            }
            // Tapping the artwork can open notification-access settings so Amazon Music artwork can be read.
            if(y>musicY+20&&y<musicY+20+cover&&x>m+5&&x<m+5+cover){
                if(albumArt==null){try{activity.startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));}catch(Exception ignored){}}
                return true;
            }
            // Weather/calendar info panel
            float lower=musicY+musicH+(wide?10:h*.018f),quickH=wide?58:Math.max(78,Math.min(h*.10f,h*.12f));if(!wide){float iy=lower+quickH+h*.018f,ih=Math.max(90,Math.min(h*.13f,h-iy-30));if(y>iy&&y<iy+ih){if(y<iy+58){loadWeather();}else{refreshCalendar();}return true;}}
        }return true;
    }

    void showAppPicker(final int slot){final ArrayList<AppInfo> choices=loadApps();String[] names=new String[choices.size()+1];names[0]="未設定（空きスロット）";for(int i=0;i<choices.size();i++)names[i+1]=choices.get(i).label;new AlertDialog.Builder(activity).setTitle("APP SLOT "+String.format("%02d",slot+1)).setItems(names,(d,w)->saveSlot(slot,w==0?"EMPTY":choices.get(w-1).label)).setNegativeButton("キャンセル",null).show();}
    void launchByLabel(String label){AppInfo a=findApp(label);if(a!=null)try{activity.startActivity(a.intent);}catch(Exception ignored){}}
    void openFairyAI(){PackageManager pm=activity.getPackageManager();Intent i=pm.getLaunchIntentForPackage("com.openai.chatgpt");if(i!=null){try{activity.startActivity(i);return;}catch(Exception ignored){}}try{activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://chatgpt.com/")));}catch(Exception ignored){}}

    void refreshMedia(){
        MediaNotificationListener.MediaState s=MediaNotificationListener.getState();
        if(s!=null){mediaTitle=s.title==null?"No active media":s.title;mediaArtist=s.artist==null?"MEDIA LINK":s.artist;mediaPlaying=s.playing;albumArt=s.art;}
    }
    void refreshCalendarIfPermitted(){if(Build.VERSION.SDK_INT<23||activity.checkSelfPermission(Manifest.permission.READ_CALENDAR)==PackageManager.PERMISSION_GRANTED)refreshCalendar();}
    void refreshCalendar(){if(Build.VERSION.SDK_INT>=23&&activity.checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED){activity.requestPermission(Manifest.permission.READ_CALENDAR,20);return;}new Thread(()->{try{long now=System.currentTimeMillis();Cursor c=activity.getContentResolver().query(CalendarContract.Instances.CONTENT_URI.buildUpon().appendPath(""+now).appendPath(""+(now+7L*24*3600*1000)).build(),new String[]{CalendarContract.Instances.EVENT_ID,CalendarContract.Instances.TITLE,CalendarContract.Instances.BEGIN},null,null,CalendarContract.Instances.BEGIN+" ASC");String s="NO UPCOMING EVENTS";if(c!=null){if(c.moveToFirst()){String title=c.getString(1);long begin=c.getLong(2);s=new SimpleDateFormat("MM/dd HH:mm",Locale.getDefault()).format(new Date(begin))+"  "+title;}c.close();}calendarLine=s;activity.runOnUiThread(this::invalidate);}catch(Exception ex){calendarLine="CALENDAR / UNAVAILABLE";activity.runOnUiThread(this::invalidate);}}).start();}

    void loadWeather(){if(Build.VERSION.SDK_INT>=23&&activity.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){activity.requestPermission(Manifest.permission.ACCESS_COARSE_LOCATION,21);return;}new Thread(()->{try{LocationManager lm=(LocationManager)activity.getSystemService(Context.LOCATION_SERVICE);Location loc=null;try{loc=lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);}catch(Exception ignored){}if(loc==null)try{loc=lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);}catch(Exception ignored){}if(loc==null){weather="LOCATION UNAVAILABLE";temperature="--°";activity.runOnUiThread(this::invalidate);return;}String url="https://api.open-meteo.com/v1/forecast?latitude="+loc.getLatitude()+"&longitude="+loc.getLongitude()+"&current=temperature_2m,weather_code&timezone=auto";HttpURLConnection con=(HttpURLConnection)new URL(url).openConnection();con.setConnectTimeout(5000);con.setReadTimeout(5000);InputStream in=con.getInputStream();BufferedReader br=new BufferedReader(new InputStreamReader(in));StringBuilder sb=new StringBuilder();String z;while((z=br.readLine())!=null)sb.append(z);JSONObject o=new JSONObject(sb.toString());JSONObject cur=o.getJSONObject("current");temperature=Math.round(cur.getDouble("temperature_2m"))+"°";weather=weatherText(cur.getInt("weather_code"));con.disconnect();activity.runOnUiThread(this::invalidate);}catch(Exception ex){weather="WEATHER / FAILED";activity.runOnUiThread(this::invalidate);}}).start();}
    String weatherText(int code){if(code==0)return"CLEAR";if(code<=3)return"CLOUDY";if(code<=48)return"FOG";if(code<=67)return"RAIN";if(code<=77)return"SNOW";if(code<=82)return"SHOWERS";return"STORM";}

    static class AppInfo{String label;Drawable icon;Intent intent;}
}
