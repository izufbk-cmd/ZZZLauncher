# ZZZ Launcher

ZZZ-style Android launcher prototype. The UI is designed to resemble the supplied terminal screenshots, with adaptive phone/tablet layouts, app cards, Fairy Assistant, music panel, mission queue, quick access cards, and an application archive.

Build with the GitHub Actions workflow in `.github/workflows/build-apk.yml` or extract the project into Android Studio.
\n\n## v1.3 customization\n- Long-press any of the 6 main app cards to choose an installed app for that slot.\n- The selection is saved on the device and survives launcher restarts.\n- Tap the FAIRY ASSISTANT ring to open the installed ChatGPT app; if it is not installed, the launcher opens ChatGPT in the browser.\n
## v1.7 Application Archive
The application archive now shows all installed launcher apps with vertical scrolling, search, launch, and long-press slot assignment.
