package com.example.zzzlauncher;

import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.MediaSessionManager;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.os.Bundle;
import java.util.List;

public class MediaNotificationListener extends NotificationListenerService {
    static volatile MediaState state = new MediaState();
    MediaSessionManager manager;
    MediaSessionManager.OnActiveSessionsChangedListener listener;
    public static MediaState getState(){return state;}
    @Override public void onListenerConnected(){
        manager=(MediaSessionManager)getSystemService(MEDIA_SESSION_SERVICE);
        listener=sessions -> update(sessions);
        try { update(manager.getActiveSessions(new android.content.ComponentName(this,MediaNotificationListener.class))); } catch(Exception ignored){}
        try { manager.addOnActiveSessionsChangedListener(listener,new android.content.ComponentName(this,MediaNotificationListener.class)); } catch(Exception ignored){}
    }
    @Override public void onListenerDisconnected(){if(manager!=null&&listener!=null)try{manager.removeOnActiveSessionsChangedListener(listener);}catch(Exception ignored){} }
    @Override public void onNotificationPosted(StatusBarNotification sbn){updateFromNotification(sbn.getNotification());}
    @Override public void onNotificationRemoved(StatusBarNotification sbn){ }
    void update(List<MediaController> sessions){
        if(sessions==null||sessions.isEmpty())return;
        for(MediaController c:sessions){MediaMetadata m=c.getMetadata();if(m!=null){apply(c,m);return;}}
    }
    void updateFromNotification(Notification n){
        if(n==null)return; Bundle ex=n.extras;if(ex==null)return; Object token=ex.get("android.mediaSession");
        if(token instanceof MediaSession.Token){try{MediaController c=new MediaController(this,(MediaSession.Token)token);MediaMetadata m=c.getMetadata();if(m!=null)apply(c,m);}catch(Exception ignored){}}
    }
    void apply(MediaController c,MediaMetadata m){
        MediaState s=new MediaState(); s.title=m.getString(MediaMetadata.METADATA_KEY_TITLE);s.artist=m.getString(MediaMetadata.METADATA_KEY_ARTIST);
        Bitmap b=m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);if(b==null)b=m.getBitmap(MediaMetadata.METADATA_KEY_ART);s.art=b;
        android.media.session.PlaybackState ps=c.getPlaybackState();s.playing=ps!=null&&ps.getState()==android.media.session.PlaybackState.STATE_PLAYING;
        s.packageName=c.getPackageName();s.controller=c;s.duration=m.getLong(MediaMetadata.METADATA_KEY_DURATION);s.position=ps==null?0:ps.getPosition();
        state=s;
    }
    static class MediaState{String title="No active media",artist="MEDIA LINK",packageName;Bitmap art;boolean playing;long position=0,duration=0;MediaController controller;}
}
